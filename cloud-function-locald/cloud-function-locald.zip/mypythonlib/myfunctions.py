

def custom_calc(a, b):
	return a*a+b